# Apply Decision What-If

Copy these paths into your Rematch repo root (overwrite):

- rematch-frontend/src/components/decision/DecisionExplorerPanel.tsx
- rematch-frontend/src/components/decision/DecisionExplorer.module.css
- rematch-frontend/src/i18n/strings.ts
- docs/WHAT_IF.md

Then open Decision Explorer on a frame-backed event and use the **Decision What-If** panel.

What-if uses only backend ranking/scores/alternatives. No frontend re-scoring. No Monte Carlo.
